from . import AccountBankStatement, AccountBankStatementLine
from . import AccountMove, AccountMoveLine
from . import note
from . import Task, ProjectTask
from . import Document
from . import StockMove, StockMoveLine
from . import StockPicking
from . import StockQuant
from . import StockScrap
from . import StockValuationLayer
from . import PurchaseOrderLine
from . import ProductTemplate
from . import hr_employee